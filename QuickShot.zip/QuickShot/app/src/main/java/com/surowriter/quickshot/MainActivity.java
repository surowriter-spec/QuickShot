package com.surowriter.quickshot;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status, detect;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            refresh();
            handler.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        SharedPreferences p = getSharedPreferences(ShotService.PREFS, MODE_PRIVATE);
        int pad = Math.round(16 * getResources().getDisplayMetrics().density);
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(pad, pad, pad, pad);

        status = new TextView(this);
        status.setTextSize(18);
        status.setTypeface(Typeface.DEFAULT_BOLD);
        c.addView(status);

        c.addView(button("1. Open Accessibility settings",
                new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        c.addView(text("Open Downloaded apps or Installed apps, choose QuickShot, and turn it on. "
                + "If it is greyed out, use the button below: tap the three dots at the top right, "
                + "choose Allow restricted settings, then try again."));
        c.addView(button("2. Open App info (only if greyed out)",
                new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName()))));

        c.addView(heading("Ways to take a screenshot"));
        c.addView(toggle(p, ShotService.KEY_ANYWHERE, true, "Double tap anywhere"));
        c.addView(text("Tap twice quickly on an empty part of the screen. Buttons, typing and "
                + "scrolling are ignored. This depends on the phone, so test it first."));
        detect = text("");
        c.addView(detect);
        c.addView(toggle(p, ShotService.KEY_STRIP, false, "Double tap the edge strip"));
        c.addView(text("Most reliable with no accidental screenshots. Double tap the pale blue "
                + "strip in the middle of the screen edge."));
        c.addView(toggle(p, ShotService.KEY_STRIP_LEFT, false, "Put the strip on the left"));
        c.addView(toggle(p, ShotService.KEY_BUTTON, false, "Floating button"));
        c.addView(text("Tap it for a screenshot. Drag it to move it."));

        ScrollView s = new ScrollView(this);
        s.addView(c);
        setContentView(s);
        s.setFitsSystemWindows(true);
    }

    private TextView text(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setPadding(0, 8, 0, 24);
        return v;
    }

    private TextView heading(String t) {
        TextView v = text(t);
        v.setTextSize(16);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setPadding(0, 32, 0, 16);
        return v;
    }

    private Button button(String t, Intent i) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setOnClickListener(x -> startActivity(i));
        return b;
    }

    private View toggle(SharedPreferences p, String key, boolean def, String label) {
        Switch sw = new Switch(this);
        sw.setText(label);
        sw.setChecked(p.getBoolean(key, def));
        sw.setPadding(0, 16, 0, 16);
        sw.setOnCheckedChangeListener((v, on) -> p.edit().putBoolean(key, on).apply());
        return sw;
    }

    private void refresh() {
        boolean on = ShotService.instance != null;
        status.setText(on ? "QuickShot is ON" : "QuickShot is OFF: complete step 1");
        status.setTextColor(on ? 0xFF2E7D32 : 0xFFC62828);
        detect.setText(!on ? "Touch test: waiting for QuickShot to be turned on"
                : "Touch test: " + ShotService.outsideTouches
                + " touches detected. If this stays at 0 when you tap, double tap anywhere "
                + "can't work on this phone, so use the strip or floating button.");
    }

    @Override protected void onResume() { super.onResume(); handler.post(tick); }
    @Override protected void onPause() { handler.removeCallbacks(tick); super.onPause(); }
}
