package com.surowriter.quickshot;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.TextView;

public class ShotService extends AccessibilityService
        implements SharedPreferences.OnSharedPreferenceChangeListener {

    static final String PREFS = "quickshot";
    static final String KEY_ANYWHERE = "anywhere";
    static final String KEY_STRIP = "strip";
    static final String KEY_STRIP_LEFT = "strip_left";
    static final String KEY_BUTTON = "button";
    private static final String KEY_BTN_X = "btn_x";
    private static final String KEY_BTN_Y = "btn_y";

    private static final long MIN_GAP = 40, MAX_GAP = 320;
    private static final long CONFIRM_DELAY = 280;
    private static final long SCROLL_OR_TYPING_BLOCK = 800;
    private static final long RAPID_TAP_BLOCK = 500;
    private static final long COOLDOWN = 1500;

    static volatile ShotService instance;
    static volatile int outsideTouches = 0;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private WindowManager wm;
    private View watcher, strip, button;
    private WindowManager.LayoutParams buttonLp;

    private long lastTap, firstTap, blockUntil, lastUiEvent, lastShot;
    private boolean pending;

    private final Runnable confirmDoubleTap = () -> {
        pending = false;
        if (lastUiEvent < firstTap - 30) shoot();
    };

    @Override
    protected void onServiceConnected() {
        instance = this;
        wm = getSystemService(WindowManager.class);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        prefs.registerOnSharedPreferenceChangeListener(this);
        rebuild();
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences p, String key) {
        if (KEY_BTN_X.equals(key) || KEY_BTN_Y.equals(key)) return;
        rebuild();
    }

    private void rebuild() {
        removeAll();
        if (prefs.getBoolean(KEY_ANYWHERE, true)) addWatcher();
        if (prefs.getBoolean(KEY_STRIP, false)) addStrip();
        if (prefs.getBoolean(KEY_BUTTON, false)) addButton();
    }

    private WindowManager.LayoutParams params(int w, int h, int flags) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(w, h,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | flags,
                PixelFormat.TRANSLUCENT);
        return lp;
    }

    /* Double tap anywhere: a 1-pixel window that is told when a touch starts elsewhere.
       It never takes the touch, so apps keep working normally. */
    private void addWatcher() {
        watcher = new View(this);
        watcher.setBackgroundColor(0x01000000);
        watcher.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_OUTSIDE) onOutsideTouch();
            return false;
        });
        WindowManager.LayoutParams lp = params(1, 1,
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH);
        lp.gravity = Gravity.TOP | Gravity.START;
        wm.addView(watcher, lp);
    }

    private void onOutsideTouch() {
        outsideTouches++;
        long now = SystemClock.uptimeMillis();
        if (pending) {
            handler.removeCallbacks(confirmDoubleTap);
            pending = false;
            lastTap = 0;
            blockUntil = now + RAPID_TAP_BLOCK;
            return;
        }
        if (now < blockUntil) {
            blockUntil = Math.max(blockUntil, now + 300);
            lastTap = 0;
            return;
        }
        long gap = now - lastTap;
        if (lastTap > 0 && gap >= MIN_GAP && gap <= MAX_GAP) {
            firstTap = lastTap;
            lastTap = 0;
            pending = true;
            handler.postDelayed(confirmDoubleTap, CONFIRM_DELAY);
        } else {
            lastTap = now;
        }
    }

    /* A tap on a button or link, a scroll or typing means the touch was not a double tap. */
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        long now = SystemClock.uptimeMillis();
        lastUiEvent = now;
        int type = event.getEventType();
        if (type == AccessibilityEvent.TYPE_VIEW_SCROLLED
                || type == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            blockUntil = Math.max(blockUntil, now + SCROLL_OR_TYPING_BLOCK);
            lastTap = 0;
        }
    }

    /* Edge strip: an invisible 24dp area on the screen edge that detects double taps itself. */
    private void addStrip() {
        strip = new View(this);
        strip.setBackgroundColor(0x2A1565C0);
        final float slop = dp(12);
        strip.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            long downAt, lastUp;
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    downX = e.getRawX();
                    downY = e.getRawY();
                    downAt = e.getEventTime();
                } else if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                    boolean isTap = e.getEventTime() - downAt < 250
                            && Math.abs(e.getRawX() - downX) < slop
                            && Math.abs(e.getRawY() - downY) < slop;
                    if (!isTap) {
                        lastUp = 0;
                    } else if (lastUp > 0 && e.getEventTime() - lastUp < 400) {
                        lastUp = 0;
                        shoot();
                    } else {
                        lastUp = e.getEventTime();
                    }
                }
                return true;
            }
        });
        DisplayMetrics dm = getResources().getDisplayMetrics();
        WindowManager.LayoutParams lp = params(dp(24), (int) (dm.heightPixels * 0.3f), 0);
        lp.gravity = (prefs.getBoolean(KEY_STRIP_LEFT, false) ? Gravity.LEFT : Gravity.RIGHT)
                | Gravity.CENTER_VERTICAL;
        wm.addView(strip, lp);
    }

    /* Floating button: drag to move, tap for a screenshot. */
    private void addButton() {
        TextView b = new TextView(this);
        b.setText("📷");
        b.setTextSize(20);
        b.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0xAA1565C0);
        b.setBackground(bg);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        buttonLp = params(dp(48), dp(48), 0);
        buttonLp.gravity = Gravity.TOP | Gravity.LEFT;
        buttonLp.x = prefs.getInt(KEY_BTN_X, dm.widthPixels - dp(60));
        buttonLp.y = prefs.getInt(KEY_BTN_Y, dm.heightPixels / 3);
        final float slop = dp(8);
        b.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean dragged;
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startX = buttonLp.x;
                        startY = buttonLp.y;
                        dragged = false;
                        break;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                        if (dragged || Math.abs(dx) > slop || Math.abs(dy) > slop) {
                            dragged = true;
                            buttonLp.x = startX + (int) dx;
                            buttonLp.y = startY + (int) dy;
                            wm.updateViewLayout(v, buttonLp);
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                        if (dragged) {
                            prefs.edit().putInt(KEY_BTN_X, buttonLp.x)
                                    .putInt(KEY_BTN_Y, buttonLp.y).apply();
                        } else {
                            v.setVisibility(View.INVISIBLE);
                            handler.postDelayed(ShotService.this::shoot, 200);
                            handler.postDelayed(() -> v.setVisibility(View.VISIBLE), 1000);
                        }
                        break;
                    default:
                        break;
                }
                return true;
            }
        });
        button = b;
        wm.addView(button, buttonLp);
    }

    private void shoot() {
        long now = SystemClock.uptimeMillis();
        if (now - lastShot < COOLDOWN) return;
        lastShot = now;
        performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void removeAll() {
        handler.removeCallbacksAndMessages(null);
        pending = false;
        lastTap = 0;
        for (View v : new View[]{watcher, strip, button}) {
            if (v != null) {
                try { wm.removeView(v); } catch (Exception ignored) { }
            }
        }
        watcher = strip = button = null;
    }

    @Override public void onInterrupt() { }

    @Override
    public boolean onUnbind(Intent intent) {
        cleanUp();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        cleanUp();
        super.onDestroy();
    }

    private void cleanUp() {
        instance = null;
        if (prefs != null) prefs.unregisterOnSharedPreferenceChangeListener(this);
        if (wm != null) removeAll();
    }
}
